import { useState } from 'react';
import { TextInput, Button, Modal, Portal, Provider, Paragraph } from 'react-native-paper';
import { ScrollView } from 'react-native';
import Lista from './Lista';
 
const ViaCep = () => {
    const [cep, setCep] = useState("");
    const [dados, setDados] = useState<any>(null);
    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");
    const [rua, setRua] = useState("");
    const [bairro, setBairro] = useState("");
    const [estado, setEstado] = useState("");
    const [cidade, setCidade] = useState("");
    const [estadoSelecionado, setEstadoSelecionado] = useState<string | null>(null);
    const [showModal, setShowModal] = useState(false);
    const [isCadastroConcluido, setCadastroConcluido] = useState(false);
    const [cepErro, setCepErro] = useState(false); // controla se houve erro na busca do CEP
 
    const BuscaCep = (cep: string) => {
        let url = `https://viacep.com.br/ws/${cep}/json/`;
 
        fetch(url)
            .then((resp) => resp.json())
            .then((dados) => {
                if (dados.erro) {
                    setShowModal(true);
                    setDados(null);
                    setCepErro(true);  // CEP incorreto, permite edição manual dos campos
                    setRua("");
                    setBairro("");
                    setEstado("");
                    setCidade("");
                } else {
                    setDados(dados);
                    setShowModal(false);
                    setCepErro(false);  // CEP correto, mantém os campos de endereço não editáveis
                    setRua(dados.logradouro || "");
                    setBairro(dados.bairro || "");
                    setEstado(dados.uf || "");
                    setCidade(dados.localidade || "");
                }
            })
            .catch((x) => {
                console.log(x);
            });
    };
 
    const handleConcluido = () => {
        if (nome && email) {
            setCadastroConcluido(true);
            // Limpa todos os campos
            setCep("");
            setDados(null);
            setNome("");
            setEmail("");
            setRua("");
            setBairro("");
            setEstado("");
            setCidade("");
            setEstadoSelecionado(null);
            setCepErro(false);
        }
    };
 
    const handleStateSelect = (estado: string) => {
        setEstadoSelecionado(estado);
        setEstado(estado);
    };
 
    // Os campos de endereço ficam editáveis somente se houve erro no CEP (cepErro == true)
    const enderecoEditable = cepErro;
 
    return (
        <Provider>
            <ScrollView style={styles.scrollContainer}>
                <Portal>
                    <Modal
                        visible={showModal}
                        onDismiss={() => setShowModal(false)}
                        contentContainerStyle={styles.modal}
                    >
                        <Paragraph>
                            CEP não encontrado. Você pode preencher os dados manualmente.
                        </Paragraph>
                    </Modal>
                </Portal>
 
                {/* Campos sempre editáveis */}
                <TextInput
                    label="Nome"
                    value={nome}
                    onChangeText={setNome}
                    mode="flat"
                    left={<TextInput.Icon name="account" />}
                    style={styles.input}
                />
 
                <TextInput
                    label="E-mail"
                    value={email}
                    onChangeText={setEmail}
                    mode="flat"
                    keyboardType="email-address"
                    left={<TextInput.Icon name="email" />}
                    style={styles.input}
                />
 
                {/* Campo CEP com limitação para 8 caracteres numéricos */}
                <TextInput
                    label="CEP"
                    value={cep}
                    onChangeText={text => setCep(text.replace(/\D/g, '').slice(0, 8))}
                    mode="flat"
                    keyboardType="numeric"
                    maxLength={8}
                    onBlur={() => BuscaCep(cep)}
                    left={<TextInput.Icon name="map-marker" />}
                    style={styles.input}
                />
 
                {/* Campos de endereço */}
                <TextInput
                    label="Rua"
                    value={rua}
                    onChangeText={setRua}
                    mode="flat"
                    editable={enderecoEditable}
                    left={<TextInput.Icon name="home" />}
                    style={styles.input}
                />
 
                <TextInput
                    label="Bairro"
                    value={bairro}
                    onChangeText={setBairro}
                    mode="flat"
                    editable={enderecoEditable}
                    left={<TextInput.Icon name="google-maps" />}
                    style={styles.input}
                />
 
                <TextInput
                    label="Estado"
                    value={estadoSelecionado || estado}
                    onChangeText={setEstado}
                    mode="flat"
                    editable={enderecoEditable}
                    left={<TextInput.Icon name="map" />}
                    style={styles.input}
                />
 
                <TextInput
                    label="Cidade"
                    value={cidade}
                    onChangeText={setCidade}
                    mode="flat"
                    editable={enderecoEditable}
                    left={<TextInput.Icon name="city" />}
                    style={styles.input}
                />
 
                <Lista dados={dados} onStateSelect={handleStateSelect} />
 
                <Button
                    mode="contained"
                    onPress={handleConcluido}
                    style={styles.button}
                    labelStyle={styles.buttonText}
                >
                    Concluído
                </Button>
 
                {isCadastroConcluido && (
                    <Paragraph style={styles.successMessage}>
                        Cadastro realizado
                    </Paragraph>
                )}
            </ScrollView>
        </Provider>
    );
};

const styles = {
    scrollContainer: {
        flex: 1,
    },
    modal: {
        backgroundColor: '#3a393b',
        padding: 20,
        margin: 20,
        borderRadius: 10,
    },
    button: {
        marginTop: 20,
        marginHorizontal: '30%',
       backgroundColor: '#23024f',
      },
      buttonText: {
        color: 'white',
      },
    successMessage: {
        marginTop: 20,
        color: 'green',
        textAlign: 'center',
    },
    input: {
        marginBottom: 10,
        backgroundColor: '#23024f',
        marginHorizontal: '30%',
        color: "#fff",
    },
};

export default ViaCep;
